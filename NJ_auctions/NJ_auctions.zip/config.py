delay_range = [3, 4]
threads = 5
full_report = False      # True or False